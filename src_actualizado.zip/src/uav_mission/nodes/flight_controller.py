#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import String
from pymavlink import mavutil
import time
import math

CONNECTION_STRING = "udp:127.0.0.1:14550"
TAKEOFF_ALTITUDE = 20.0
CRUISE_SPEED = 3.0

class FlightController(Node):

    def __init__(self):
        super().__init__('flight_controller')

        self.pose_pub = self.create_publisher(PoseStamped, '/uav/local_position', 10)
        self.state_pub = self.create_publisher(String, '/uav/state', 10)

        self.connection = mavutil.mavlink_connection(CONNECTION_STRING)
        self.connection.wait_heartbeat()

        self.phase = "TAKEOFF"
        self.altitude_reached = False

        self.timer = self.create_timer(0.1, self.loop)

    # ---------------- MAVLINK ----------------

    def set_mode(self, mode):
        self.connection.set_mode(mode)

    def arm(self):
        self.connection.arducopter_arm()
        self.connection.motors_armed_wait()

    def takeoff(self, alt):
        self.connection.mav.command_long_send(
            self.connection.target_system,
            self.connection.target_component,
            mavutil.mavlink.MAV_CMD_NAV_TAKEOFF,
            0, 0, 0, 0, 0, 0, 0, alt)

    def send_forward_velocity(self, speed):
        self.connection.mav.set_position_target_local_ned_send(
            0,
            self.connection.target_system,
            self.connection.target_component,
            mavutil.mavlink.MAV_FRAME_BODY_NED,
            0b0000111111000111,
            0, 0, 0,
            speed, 0, 0,
            0, 0, 0,
            0, 0)

    def get_local_position(self):
        msg = self.connection.recv_match(type='LOCAL_POSITION_NED', blocking=False)
        if msg:
            return msg.x, msg.y, -msg.z
        return None

    # ---------------- MAIN LOOP ----------------

    def loop(self):
        pos = self.get_local_position()
        if pos:
            x, y, z = pos

            pose = PoseStamped()
            pose.header.stamp = self.get_clock().now().to_msg()
            pose.pose.position.x = x
            pose.pose.position.y = y
            pose.pose.position.z = z
            self.pose_pub.publish(pose)

            if self.phase == "TAKEOFF":
                self.set_mode("GUIDED")
                self.arm()
                time.sleep(2)
                self.takeoff(TAKEOFF_ALTITUDE)
                self.phase = "WAIT_ALT"

            elif self.phase == "WAIT_ALT":
                if z >= TAKEOFF_ALTITUDE * 0.95:
                    self.phase = "CRUISE"

            elif self.phase == "CRUISE":
                self.send_forward_velocity(CRUISE_SPEED)

            self.state_pub.publish(String(data=self.phase))


def main():
    rclpy.init()
    node = FlightController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
