#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Empty
import math

PHOTO_EVERY_M = 10.0

class PhotoTrigger(Node):

    def __init__(self):
        super().__init__('photo_trigger')

        self.sub = self.create_subscription(
            PoseStamped,
            '/uav/local_position',
            self.pose_callback,
            10)

        self.trigger_pub = self.create_publisher(Empty, '/photo/take', 10)

        self.prev_x = None
        self.prev_y = None
        self.accumulated = 0.0

    def pose_callback(self, msg):
        x = msg.pose.position.x
        y = msg.pose.position.y

        if self.prev_x is not None:
            dx = x - self.prev_x
            dy = y - self.prev_y
            self.accumulated += math.sqrt(dx*dx + dy*dy)

            if self.accumulated >= PHOTO_EVERY_M:
                self.trigger_pub.publish(Empty())
                self.accumulated = 0.0

        self.prev_x = x
        self.prev_y = y


def main():
    rclpy.init()
    node = PhotoTrigger()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
