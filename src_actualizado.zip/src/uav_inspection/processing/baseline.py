import os
import cv2

def build_baseline_map(folder):
    baseline = {}
    for f in sorted(os.listdir(folder)):
        if f.endswith(".jpg") or f.endswith(".png"):
            path = os.path.join(folder, f)
            img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
            baseline[f] = img
    return baseline
