import cv2
import numpy as np

def road_change_score(base, current, mask):
    diff = cv2.absdiff(base, current)
    diff_masked = cv2.bitwise_and(diff, diff, mask=mask)
    score = np.sum(diff_masked) / 255.0
    return score, diff_masked
