import cv2
import numpy as np

def ecc_align_translation(im1_gray, im2_gray):
    warp = np.eye(2,3, dtype=np.float32)
    criteria = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 50, 1e-6)
    cc, warp = cv2.findTransformECC(im1_gray, im2_gray, warp, cv2.MOTION_TRANSLATION, criteria)
    aligned = cv2.warpAffine(im2_gray, warp, (im1_gray.shape[1], im1_gray.shape[0]),
                             flags=cv2.INTER_LINEAR + cv2.WARP_INVERSE_MAP)
    return aligned
