import numpy as np
import cv2
import math

def dist2d(x1, y1, x2, y2):
    return math.sqrt((x1-x2)**2 + (y1-y2)**2)

def polygon_mask(shape, polygon_rel):
    h, w = shape[:2]
    pts = np.array([[int(px*w), int(py*h)] for px,py in polygon_rel], dtype=np.int32)
    mask = np.zeros((h,w), dtype=np.uint8)
    cv2.fillPoly(mask, [pts], 255)
    return mask
