#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import Empty, String
from cv_bridge import CvBridge
import cv2
import os
import time

SAVE_DIR = os.path.expanduser(
    "~/Documentos/GitHub/IR2136/data/incoming"
)

os.makedirs(SAVE_DIR, exist_ok=True)

class PhotoLogger(Node):

    def __init__(self):
        super().__init__('photo_logger')

        self.bridge = CvBridge()
        self.last_image = None

        self.image_sub = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.image_callback,
            10)

        self.trigger_sub = self.create_subscription(
            Empty,
            '/photo/take',
            self.take_photo,
            10)

        self.path_pub = self.create_publisher(String, '/photo/latest_path', 10)

    def image_callback(self, msg):
        self.last_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')

    def take_photo(self, _):
        if self.last_image is None:
            return

        filename = f"{int(time.time())}.jpg"
        path = os.path.join(SAVE_DIR, filename)
        cv2.imwrite(path, self.last_image)

        self.path_pub.publish(String(data=path))


def main():
    rclpy.init()
    node = PhotoLogger()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
