#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import os
import json

from uav_inspection.processing.baseline import build_baseline_map
from uav_inspection.processing.alignment import ecc_align_translation
from uav_inspection.processing.scoring import road_change_score
from uav_inspection.processing.geometry import polygon_mask

BASELINE_FOLDER = os.path.expanduser(
    "~/Documentos/GitHub/IR2136/src/uav_inspection/data/baseline"
)

MIN_GAP_M = 15.0
SCORE_THRESHOLD = 20000

ROAD_POLY_REL = [
    (0.2,0.8),
    (0.8,0.8),
    (0.8,0.6),
    (0.2,0.6)
]

class IncidentDetector(Node):

    def __init__(self):
        super().__init__('incident_detector')

        self.bridge = CvBridge()
        self.baseline_map = build_baseline_map(BASELINE_FOLDER)
        self.last_incident_pos = None

        self.sub = self.create_subscription(
            String,
            '/photo/latest_path',
            self.process_image,
            10)

        self.annotated_pub = self.create_publisher(Image, '/annotated/image', 10)
        self.json_pub = self.create_publisher(String, '/incidents/json', 10)

    def process_image(self, msg):
        img_color = cv2.imread(msg.data)
        if img_color is None:
            return

        img_gray = cv2.cvtColor(img_color, cv2.COLOR_BGR2GRAY)

        if not self.baseline_map:
            return

        baseline_gray = list(self.baseline_map.values())[0]

        aligned = ecc_align_translation(baseline_gray, img_gray)

        mask = polygon_mask(img_gray.shape, ROAD_POLY_REL)

        score, diff = road_change_score(baseline_gray, aligned, mask)

        if score > SCORE_THRESHOLD:

            overlay = img_color.copy()
            overlay[diff > 20] = [0,0,255]

            self.annotated_pub.publish(
                self.bridge.cv2_to_imgmsg(overlay, encoding='bgr8')
            )

            incident = {
                "score": float(score),
                "image": msg.data
            }

            self.json_pub.publish(String(data=json.dumps(incident)))
